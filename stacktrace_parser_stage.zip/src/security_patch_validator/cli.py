"""Command-line interface for Security Patch Validator."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from security_patch_validator.patch_analysis.diff_analyzer import analyze_diff
from security_patch_validator.patch_analysis.stacktrace_parser import parse_execution_result
from security_patch_validator.patch_analysis.version_comparator import (
    VersionComparisonError,
    compare_versions,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="spv",
        description="Security Patch Validator - compare and analyze Git versions.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    for command, help_text in (
        ("compare", "Compare two committed versions and list changed files."),
        ("diff", "Analyze line-level Git Diff changes between two commits."),
    ):
        command_parser = subparsers.add_parser(command, help=help_text)
        command_parser.add_argument("--repo", default=".", help="Git repository root (default: current directory).")
        command_parser.add_argument("--base", required=True, help="Base commit, tag, or branch.")
        command_parser.add_argument("--patched", required=True, help="Patched commit, tag, or branch.")
        command_parser.add_argument("--output", help="Write JSON report to this path instead of stdout.")
        command_parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output.")

    trace_parser = subparsers.add_parser("parse-trace", help="Parse sanitizer output from a runner JSON file.")
    trace_parser.add_argument("--input", required=True, help="Path to the runner's JSON execution result.")
    trace_parser.add_argument("--output", help="Write parsed JSON to this path instead of stdout.")
    trace_parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output.")

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    try:
        if args.command == "compare":
            report = compare_versions(args.repo, args.base, args.patched)
        elif args.command == "diff":
            report = analyze_diff(args.repo, args.base, args.patched)
        elif args.command == "parse-trace":
            input_data = json.loads(Path(args.input).read_text(encoding="utf-8"))
            report = parse_execution_result(input_data)
        else:
            parser.error("Unsupported command.")
            return 2
    except (VersionComparisonError, OSError, ValueError, TypeError) as exc:
        print(f"spv: error: {exc}", file=sys.stderr)
        return 1

    output = json.dumps(report, ensure_ascii=False, indent=2 if args.pretty else None)

    if args.output:
        output_path = Path(args.output).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output + "\n", encoding="utf-8")
    else:
        print(output)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
